﻿#pragma once

#include "CustomElixir.h"

namespace ZenBarApp {
    using namespace System;
    using namespace System::Collections::Generic;
    using namespace System::Drawing;
    using namespace System::Windows::Forms;

    public ref class MyForm : public Form
    {
    private:
        // ZenBar's visual system: sage, blush, warm cream and deep botanical green.
        Panel^ sidebar;
        Panel^ mainArea;
        Panel^ topbar;
        Panel^ pageHost;
        Label^ pageHeading;
        Label^ pageEyebrow;
        Label^ cartCountLabel;
        Label^ welcomeLabel;
        FlowLayoutPanel^ menuFlow;
        DataGridView^ ordersGrid;
        Dictionary<String^, int>^ cart;
        Dictionary<String^, double>^ prices;
        Dictionary<String^, String^>^ descriptions;
        Dictionary<String^, String^>^ icons;
        List<Product^>^ oopProducts;
        List<Button^>^ navigationButtons;
        String^ currentPage;
        int navWidth;
        int nextOrderNumber;

        Color Ink()       { return Color::FromArgb(47, 59, 49); }
        Color Muted()     { return Color::FromArgb(125, 132, 119); }
        Color Sage()      { return Color::FromArgb(139, 166, 139); }
        Color SageLight() { return Color::FromArgb(226, 236, 220); }
        Color Forest()    { return Color::FromArgb(48, 78, 58); }
        Color Cream()     { return Color::FromArgb(250, 247, 239); }
        Color White()     { return Color::FromArgb(255, 255, 252); }
        Color Blush()     { return Color::FromArgb(246, 222, 218); }
        Color BlushDark() { return Color::FromArgb(173, 104, 106); }
        Color Butter()    { return Color::FromArgb(248, 235, 195); }
        Color Line()      { return Color::FromArgb(231, 229, 216); }

        Label^ MakeLabel(String^ text, float size, Color color, bool bold) {
            Label^ l = gcnew Label();
            l->Text = text;
            l->AutoSize = true;
            l->ForeColor = color;
            l->Font = gcnew Drawing::Font(L"Segoe UI", size, bold ? FontStyle::Bold : FontStyle::Regular);
            l->BackColor = Color::Transparent;
            return l;
        }

        Button^ MakeButton(String^ text, Color back, Color fore, int width, int height) {
            Button^ b = gcnew Button();
            b->Text = text;
            b->Size = Drawing::Size(width, height);
            b->BackColor = back;
            b->ForeColor = fore;
            b->FlatStyle = FlatStyle::Flat;
            b->FlatAppearance->BorderSize = 0;
            b->Font = gcnew Drawing::Font(L"Segoe UI", 9.5f, FontStyle::Bold);
            b->Cursor = Cursors::Hand;
            b->UseVisualStyleBackColor = false;
            b->TabStop = true;
            return b;
        }

        Panel^ MakePanel(Color back, int width, int height) {
            Panel^ p = gcnew Panel();
            p->BackColor = back;
            p->Size = Drawing::Size(width, height);
            return p;
        }

        void StyleCard(Panel^ p) {
            p->BackColor = White();
            p->Padding = Windows::Forms::Padding(0);
            p->BorderStyle = BorderStyle::FixedSingle;
        }

        void AddNavButton(String^ text, String^ pageKey, int y, bool selected) {
            Button^ b = MakeButton(text, selected ? Color::FromArgb(71, 105, 78) : Forest(),
                selected ? Color::White : Color::FromArgb(222, 231, 219), 204, 44);
            b->Location = Point(17, y);
            b->TextAlign = ContentAlignment::MiddleLeft;
            b->Padding = Windows::Forms::Padding(15, 0, 0, 0);
            b->Font = gcnew Drawing::Font(L"Segoe UI", 10, selected ? FontStyle::Bold : FontStyle::Regular);
            b->Tag = pageKey;
            b->Click += gcnew EventHandler(this, &MyForm::Navigation_Click);
            navigationButtons->Add(b);
            sidebar->Controls->Add(b);
        }

        void SetPage(String^ key, String^ title, String^ eyebrow) {
            currentPage = key;
            pageHeading->Text = title;
            pageEyebrow->Text = eyebrow;
            pageHost->Controls->Clear();
            if (key == "overview") BuildDashboard();
            else if (key == "menu") BuildMenuPage();
            else if (key == "orders") BuildOrdersPage();
            else if (key == "bookings") BuildBookingsPage();
            else if (key == "wellness") BuildWellnessPage();
            else if (key == "about") BuildAboutPage();
            UpdateCartCount();
        }

        void Navigation_Click(Object^ sender, EventArgs^ e) {
            Button^ b = safe_cast<Button^>(sender);
            String^ key = safe_cast<String^>(b->Tag);
            for each (Button^ nav in navigationButtons) {
                bool active = safe_cast<String^>(nav->Tag) == key;
                nav->BackColor = active ? Color::FromArgb(71, 105, 78) : Forest();
                nav->ForeColor = active ? Color::White : Color::FromArgb(222, 231, 219);
                nav->Font = gcnew Drawing::Font(L"Segoe UI", 10, active ? FontStyle::Bold : FontStyle::Regular);
            }
            if (key == "overview") SetPage(key, "A little moment for yourself.", "YOUR ZENBAR SPACE");
            else if (key == "menu") SetPage(key, "Find your feel-good blend.", "THE MENU");
            else if (key == "orders") SetPage(key, "Your little list of goodness.", "YOUR ORDER");
            else if (key == "bookings") SetPage(key, "Make a little room for you.", "VISIT ZENBAR");
            else if (key == "wellness") SetPage(key, "How would you like to feel?", "YOUR WELLNESS RITUAL");
            else SetPage(key, "A softer kind of everyday.", "OUR LITTLE STORY");
        }

        void UpdateCartCount() {
            int count = 0;
            for each (KeyValuePair<String^, int> item in cart) count += item.Value;
            if (cartCountLabel != nullptr) cartCountLabel->Text = "Bag  ·  " + count.ToString();
        }

        double CartTotal() {
            double total = 0;
            for each (KeyValuePair<String^, int> item in cart) total += prices[item.Key] * item.Value;
            return total;
        }

        void AddProduct(String^ name) {
            if (cart->ContainsKey(name)) cart[name] = cart[name] + 1;
            else cart->Add(name, 1);
            UpdateCartCount();
            MessageBox::Show(name + " has been added to your bag.\n\nYour bag total: LKR " + CartTotal().ToString("0.00"),
                "A little goodness added!", MessageBoxButtons::OK, MessageBoxIcon::Information);
        }

        void AddProductCard(String^ icon, String^ name, String^ description, String^ price, Color tint, int width) {
            Panel^ card = MakePanel(White(), width, 240);
            card->Margin = Windows::Forms::Padding(0, 0, 15, 15);
            card->BorderStyle = BorderStyle::FixedSingle;
            Panel^ art = MakePanel(tint, width - 2, 86);
            art->Location = Point(1, 1);
            Label^ emoji = MakeLabel(icon, 32, Forest(), true);
            emoji->AutoSize = false; emoji->TextAlign = ContentAlignment::MiddleCenter;
            emoji->Dock = DockStyle::Fill; art->Controls->Add(emoji);
            Label^ nm = MakeLabel(name, 13, Ink(), true); nm->Location = Point(15, 100);
            Label^ desc = MakeLabel(description, 8.5f, Muted(), false); desc->Location = Point(15, 126);
            Label^ pr = MakeLabel(price, 12, Forest(), true); pr->Location = Point(15, 157);
            Button^ add = MakeButton("＋  Add to bag", Forest(), Color::White, width - 30, 34);
            add->Location = Point(15, 190); add->Tag = name;
            add->Click += gcnew EventHandler(this, &MyForm::AddToBag_Click);
            card->Controls->Add(art); card->Controls->Add(nm); card->Controls->Add(desc); card->Controls->Add(pr); card->Controls->Add(add);
            menuFlow->Controls->Add(card);
        }

        void AddSectionTitle(String^ title, String^ subtitle, int y) {
            Label^ h = MakeLabel(title, 16, Ink(), true); h->Location = Point(30, y); pageHost->Controls->Add(h);
            Label^ s = MakeLabel(subtitle, 9, Muted(), false); s->Location = Point(31, y + 29); pageHost->Controls->Add(s);
        }

        Panel^ AddStatCard(String^ icon, String^ label, String^ value, String^ note, int x, int y, Color tint, int width) {
            Panel^ card = MakePanel(White(), width, 112); card->Location = Point(x, y); card->BorderStyle = BorderStyle::FixedSingle;
            Panel^ bubble = MakePanel(tint, 43, 43); bubble->Location = Point(15, 18);
            Label^ i = MakeLabel(icon, 17, Forest(), true); i->AutoSize = false; i->Dock = DockStyle::Fill; i->TextAlign = ContentAlignment::MiddleCenter; bubble->Controls->Add(i);
            Label^ l = MakeLabel(label, 8, Muted(), true); l->Location = Point(70, 16);
            Label^ v = MakeLabel(value, 16, Ink(), true); v->Location = Point(70, 37);
            Label^ n = MakeLabel(note, 8, Muted(), false); n->Location = Point(70, 73);
            card->Controls->Add(bubble); card->Controls->Add(l); card->Controls->Add(v); card->Controls->Add(n); pageHost->Controls->Add(card);
            return card;
        }

        void BuildDashboard() {
            int w = Math::Max(760, pageHost->ClientSize.Width - 58);
            Panel^ hero = MakePanel(SageLight(), w, 205); hero->Location = Point(28, 20); hero->BorderStyle = BorderStyle::None;
            Label^ tag = MakeLabel("A SMALL PAUSE, JUST FOR YOU", 8, Forest(), true); tag->Location = Point(27, 24);
            Label^ title = MakeLabel("Feel good. Sip slowly.", 25, Ink(), true); title->Location = Point(25, 51);
            Label^ copy = MakeLabel("Fresh blends, lovely ingredients, and little moments\nthat help you feel a little more like yourself.", 10, Color::FromArgb(82, 103, 83), false);
            copy->Location = Point(28, 94); copy->Size = Drawing::Size(440, 45);
            Button^ explore = MakeButton("Explore the menu   →", Forest(), Color::White, 174, 38); explore->Location = Point(27, 151);
            explore->Click += gcnew EventHandler(this, &MyForm::GoMenu_Click);
            Panel^ decorative = MakePanel(Color::FromArgb(207, 225, 198), 165, 145); decorative->Location = Point(w - 210, 29); decorative->BorderStyle = BorderStyle::None;
            Label^ flower = MakeLabel("✿", 76, Color::FromArgb(93, 130, 89), true); flower->AutoSize = false; flower->Dock = DockStyle::Fill; flower->TextAlign = ContentAlignment::MiddleCenter; decorative->Controls->Add(flower);
            Label^ stamp = MakeLabel("BLENDED WITH A LITTLE LOVE", 8, Forest(), true); stamp->Location = Point(w - 220, 177);
            hero->Controls->Add(tag); hero->Controls->Add(title); hero->Controls->Add(copy); hero->Controls->Add(explore); hero->Controls->Add(decorative); hero->Controls->Add(stamp);
            pageHost->Controls->Add(hero);

            AddSectionTitle("Your little overview", "A few nice things to make your day", 248);
            int gap = 14; int statW = (w - gap * 2) / 3;
            AddStatCard("✿", "TODAY'S PICK", "Matcha Cloud", "A gentle, creamy boost", 28, 307, Blush(), statW);
            AddStatCard("♡", "YOUR RITUAL", "Small steps count", "A little care goes a long way", 28 + statW + gap, 307, SageLight(), statW);
            Panel^ quick = AddStatCard("↗", "QUICK ACTION", "Plan a visit", "Come by for a little reset", 28 + (statW + gap) * 2, 307, Butter(), statW);
            Button^ book = MakeButton("Book  →", Forest(), Color::White, 82, 28); book->Location = Point(statW - 96, 73); book->Font = gcnew Drawing::Font(L"Segoe UI", 8, FontStyle::Bold); book->Click += gcnew EventHandler(this, &MyForm::GoBookings_Click); quick->Controls->Add(book);

            AddSectionTitle("A few favourites", "Good mood in a cup — pick the one calling your name", 446);
            menuFlow = gcnew FlowLayoutPanel(); menuFlow->Location = Point(28, 496); menuFlow->Size = Drawing::Size(w, 260); menuFlow->BackColor = Cream(); menuFlow->WrapContents = false; menuFlow->AutoScroll = true; menuFlow->FlowDirection = FlowDirection::LeftToRight;
            pageHost->Controls->Add(menuFlow);
            AddProductCard("🍓", "Berry Bloom", "Strawberry · hibiscus · honey", "LKR 790", Blush(), 220);
            AddProductCard("🍵", "Matcha Cloud", "Matcha · oat milk · vanilla", "LKR 850", SageLight(), 220);
            AddProductCard("🥭", "Golden Hour", "Mango · turmeric · ginger", "LKR 820", Butter(), 220);
            AddProductCard("🫐", "Blueberry Calm", "Blueberry · yogurt · chia", "LKR 890", Color::FromArgb(229, 225, 242), 220);
            Label^ foot = MakeLabel("MADE WITH CARE  ·  MADE FOR YOU", 8, Muted(), true); foot->Location = Point(30, 773); pageHost->Controls->Add(foot);
        }

        void BuildMenuPage() {
            int w = Math::Max(740, pageHost->ClientSize.Width - 58);
            Panel^ intro = MakePanel(Blush(), w, 105); intro->Location = Point(28, 18); intro->BorderStyle = BorderStyle::None;
            Label^ a = MakeLabel("A MENU WITH GOOD INTENTIONS", 8, BlushDark(), true); a->Location = Point(22, 18);
            Label^ b = MakeLabel("Find your new favourite.", 20, Ink(), true); b->Location = Point(20, 40);
            Label^ c = MakeLabel("Freshly made, thoughtfully blended, always a little joyful.", 9, Muted(), false); c->Location = Point(22, 74);
            intro->Controls->Add(a); intro->Controls->Add(b); intro->Controls->Add(c); pageHost->Controls->Add(intro);
            menuFlow = gcnew FlowLayoutPanel(); menuFlow->Location = Point(28, 143); menuFlow->Size = Drawing::Size(w, 560); menuFlow->BackColor = Cream(); menuFlow->AutoScroll = true; menuFlow->WrapContents = true; menuFlow->FlowDirection = FlowDirection::LeftToRight; pageHost->Controls->Add(menuFlow);
            AddProductCard("🍓", "Berry Bloom", "Strawberry · hibiscus · honey", "LKR 790", Blush(), 220);
            AddProductCard("🍵", "Matcha Cloud", "Matcha · oat milk · vanilla", "LKR 850", SageLight(), 220);
            AddProductCard("🥭", "Golden Hour", "Mango · turmeric · ginger", "LKR 820", Butter(), 220);
            AddProductCard("🫐", "Blueberry Calm", "Blueberry · yogurt · chia", "LKR 890", Color::FromArgb(229, 225, 242), 220);
            AddProductCard("🍍", "Sunny Side", "Pineapple · lime · mint", "LKR 760", Color::FromArgb(247, 231, 183), 220);
            AddProductCard("🌸", "Rose Cloud", "Rose · vanilla · oat milk", "LKR 880", Blush(), 220);
        }

        void BuildOrdersPage() {
            int w = Math::Max(740, pageHost->ClientSize.Width - 58);
            Panel^ hero = MakePanel(SageLight(), w, 115); hero->Location = Point(28, 18); hero->BorderStyle = BorderStyle::None;
            Label^ h = MakeLabel("Your bag, your way.", 21, Ink(), true); h->Location = Point(22, 22);
            Label^ sub = MakeLabel("Add a favourite from the menu, then place your order when you're ready.", 9, Muted(), false); sub->Location = Point(24, 58);
            Label^ total = MakeLabel("Current total: LKR " + CartTotal().ToString("0.00"), 12, Forest(), true); total->Location = Point(24, 83); total->Name = "orderTotalLabel";
            hero->Controls->Add(h); hero->Controls->Add(sub); hero->Controls->Add(total); pageHost->Controls->Add(hero);

            Panel^ list = MakePanel(White(), w, 330); list->Location = Point(28, 150); list->BorderStyle = BorderStyle::FixedSingle;
            Label^ listTitle = MakeLabel("IN YOUR BAG", 9, Muted(), true); listTitle->Location = Point(20, 18); list->Controls->Add(listTitle);
            DataGridView^ grid = gcnew DataGridView(); grid->Location = Point(18, 48); grid->Size = Drawing::Size(w - 38, 205); grid->ReadOnly = true; grid->AllowUserToAddRows = false; grid->AllowUserToDeleteRows = false; grid->RowHeadersVisible = false; grid->AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode::Fill; grid->BackgroundColor = White(); grid->BorderStyle = BorderStyle::None; grid->SelectionMode = DataGridViewSelectionMode::FullRowSelect; grid->MultiSelect = false;
            grid->ColumnHeadersDefaultCellStyle->BackColor = SageLight(); grid->ColumnHeadersDefaultCellStyle->ForeColor = Forest(); grid->EnableHeadersVisualStyles = false; grid->ColumnHeadersHeight = 34; grid->RowTemplate->Height = 32;
            grid->Columns->Add("drink", "Blend"); grid->Columns->Add("qty", "Qty"); grid->Columns->Add("price", "Unit price"); grid->Columns->Add("subtotal", "Subtotal");
            for each (KeyValuePair<String^, int> item in cart) grid->Rows->Add(item.Key, item.Value.ToString(), "LKR " + prices[item.Key].ToString("0.00"), "LKR " + (prices[item.Key] * item.Value).ToString("0.00"));
            list->Controls->Add(grid);
            Button^ remove = MakeButton("Remove selected", Blush(), BlushDark(), 145, 34); remove->Location = Point(18, 270);
            remove->Click += gcnew EventHandler(this, &MyForm::RemoveOrder_Click); remove->Tag = grid; list->Controls->Add(remove);
            Button^ clear = MakeButton("Clear bag", Color::FromArgb(241, 239, 229), Ink(), 105, 34); clear->Location = Point(172, 270); clear->Click += gcnew EventHandler(this, &MyForm::ClearBag_Click); list->Controls->Add(clear);
            Button^ place = MakeButton("Place order  →", Forest(), Color::White, 150, 34); place->Location = Point(w - 180, 270); place->Click += gcnew EventHandler(this, &MyForm::PlaceOrder_Click); list->Controls->Add(place);
            pageHost->Controls->Add(list);
            if (cart->Count == 0) { Label^ empty = MakeLabel("Your bag is waiting for something lovely. Visit the menu to add a blend.", 9, Muted(), false); empty->Location = Point(48, 425); pageHost->Controls->Add(empty); }
        }

        void BuildBookingsPage() {
            int w = Math::Max(740, pageHost->ClientSize.Width - 58);
            Panel^ card = MakePanel(White(), Math::Min(w, 720), 455); card->Location = Point(28, 20); card->BorderStyle = BorderStyle::FixedSingle;
            Panel^ banner = MakePanel(Blush(), card->Width - 2, 105); banner->Location = Point(1, 1); banner->BorderStyle = BorderStyle::None;
            Label^ bt = MakeLabel("Your table is waiting. ♡", 20, Ink(), true); bt->Location = Point(22, 20);
            Label^ bs = MakeLabel("A little time out, a lovely drink, a softer day.", 9, Muted(), false); bs->Location = Point(24, 56); banner->Controls->Add(bt); banner->Controls->Add(bs); card->Controls->Add(banner);
            Label^ dateLabel = MakeLabel("CHOOSE A DATE", 8, Muted(), true); dateLabel->Location = Point(25, 132);
            DateTimePicker^ date = gcnew DateTimePicker(); date->Location = Point(25, 155); date->Size = Drawing::Size(300, 34); date->Font = gcnew Drawing::Font(L"Segoe UI", 10); date->MinDate = DateTime::Today; date->Format = DateTimePickerFormat::Long; date->Name = "bookingDate";
            Label^ timeLabel = MakeLabel("PREFERRED TIME", 8, Muted(), true); timeLabel->Location = Point(25, 210);
            ComboBox^ time = gcnew ComboBox(); time->Location = Point(25, 233); time->Size = Drawing::Size(300, 34); time->DropDownStyle = ComboBoxStyle::DropDownList; time->Font = gcnew Drawing::Font(L"Segoe UI", 10); time->Items->AddRange(gcnew array<Object^>{"10:00 AM", "11:30 AM", "01:00 PM", "02:30 PM", "04:00 PM", "05:30 PM"}); time->SelectedIndex = 0; time->Name = "bookingTime";
            Label^ guestsLabel = MakeLabel("NUMBER OF GUESTS", 8, Muted(), true); guestsLabel->Location = Point(25, 288);
            NumericUpDown^ guests = gcnew NumericUpDown(); guests->Location = Point(25, 311); guests->Size = Drawing::Size(120, 32); guests->Minimum = 1; guests->Maximum = 12; guests->Value = 2; guests->Font = gcnew Drawing::Font(L"Segoe UI", 10); guests->Name = "bookingGuests";
            Label^ note = MakeLabel("Bookings are a demo feature for this OOP project.\nYour request will be confirmed on screen.", 9, Muted(), false); note->Location = Point(25, 363); note->Size = Drawing::Size(500, 42);
            Button^ submit = MakeButton("Request a booking  →", Forest(), Color::White, 205, 40); submit->Location = Point(25, 410); submit->Tag = card; submit->Click += gcnew EventHandler(this, &MyForm::SubmitBooking_Click);
            card->Controls->Add(dateLabel); card->Controls->Add(date); card->Controls->Add(timeLabel); card->Controls->Add(time); card->Controls->Add(guestsLabel); card->Controls->Add(guests); card->Controls->Add(note); card->Controls->Add(submit); pageHost->Controls->Add(card);
        }

        void BuildWellnessPage() {
            int w = Math::Max(740, pageHost->ClientSize.Width - 58);
            Panel^ hero = MakePanel(SageLight(), w, 130); hero->Location = Point(28, 18); hero->BorderStyle = BorderStyle::None;
            Label^ title = MakeLabel("A check-in with yourself. ✿", 21, Ink(), true); title->Location = Point(22, 23);
            Label^ sub = MakeLabel("No pressure to be perfect. Just pick the feeling you need a little more of today.", 9, Muted(), false); sub->Location = Point(24, 62); sub->Size = Drawing::Size(w - 48, 30);
            hero->Controls->Add(title); hero->Controls->Add(sub); pageHost->Controls->Add(hero);
            AddSectionTitle("What would feel good today?", "Choose a mood to get a gentle blend suggestion", 180);
            array<String^>^ moods = gcnew array<String^>{"I need a little energy", "I want to feel calm", "I want something bright", "I need a small treat"};
            array<String^>^ recs = gcnew array<String^>{"Golden Hour — mango, turmeric and ginger", "Matcha Cloud — matcha, oat milk and vanilla", "Sunny Side — pineapple, lime and mint", "Berry Bloom — strawberry, hibiscus and honey"};
            array<Color>^ tints = gcnew array<Color>{Butter(), SageLight(), Color::FromArgb(247, 231, 183), Blush()};
            for (int i = 0; i < moods->Length; i++) {
                Panel^ c = MakePanel(White(), w - 2, 77); c->Location = Point(28, 245 + i * 91); c->BorderStyle = BorderStyle::FixedSingle;
                Panel^ dot = MakePanel(tints[i], 43, 43); dot->Location = Point(16, 16);
                Label^ symbol = MakeLabel(i == 0 ? "☀" : (i == 1 ? "☾" : (i == 2 ? "✿" : "♡")), 16, Forest(), true); symbol->AutoSize = false; symbol->Dock = DockStyle::Fill; symbol->TextAlign = ContentAlignment::MiddleCenter; dot->Controls->Add(symbol);
                Label^ m = MakeLabel(moods[i], 10, Ink(), true); m->Location = Point(73, 15);
                Label^ r = MakeLabel(recs[i], 8.5f, Muted(), false); r->Location = Point(74, 39);
                Button^ pick = MakeButton("Choose blend  →", Forest(), Color::White, 132, 34); pick->Location = Point(w - 160, 21); pick->Tag = i; pick->Click += gcnew EventHandler(this, &MyForm::MoodPick_Click);
                c->Controls->Add(dot); c->Controls->Add(m); c->Controls->Add(r); c->Controls->Add(pick); pageHost->Controls->Add(c);
            }
        }

        void BuildAboutPage() {
            int w = Math::Max(740, pageHost->ClientSize.Width - 58);
            Panel^ hero = MakePanel(Blush(), w, 190); hero->Location = Point(28, 20); hero->BorderStyle = BorderStyle::None;
            Label^ eyebrow = MakeLabel("OUR LITTLE STORY", 8, BlushDark(), true); eyebrow->Location = Point(25, 25);
            Label^ heading = MakeLabel("A softer kind of everyday.", 24, Ink(), true); heading->Location = Point(23, 54);
            Label^ text = MakeLabel("ZenBar is a feel-good wellness bar concept built around\nfresh blends, thoughtful ingredients, and small moments\nof care in the middle of a busy day.", 10, Muted(), false); text->Location = Point(26, 100); text->Size = Drawing::Size(560, 70);
            hero->Controls->Add(eyebrow); hero->Controls->Add(heading); hero->Controls->Add(text); pageHost->Controls->Add(hero);
            AddSectionTitle("Made with intention", "A few things at the heart of ZenBar", 240);
            array<String^>^ heads = gcnew array<String^>{"Fresh by nature", "Personal by design", "Gentle by spirit"};
            array<String^>^ descs = gcnew array<String^>{"Bright ingredients and feel-good combinations.", "Your mood, your choices, your kind of blend.", "A welcoming place to pause and reset."};
            array<Color>^ colors = gcnew array<Color>{SageLight(), Blush(), Butter()};
            int cardW = (w - 32) / 3;
            for (int i = 0; i < 3; i++) {
                Panel^ c = MakePanel(White(), cardW, 140); c->Location = Point(28 + i * (cardW + 16), 300); c->BorderStyle = BorderStyle::FixedSingle;
                Panel^ icon = MakePanel(colors[i], 42, 42); icon->Location = Point(17, 17);
                Label^ sym = MakeLabel(i == 0 ? "✿" : (i == 1 ? "♡" : "☼"), 18, Forest(), true); sym->AutoSize = false; sym->Dock = DockStyle::Fill; sym->TextAlign = ContentAlignment::MiddleCenter; icon->Controls->Add(sym);
                Label^ h = MakeLabel(heads[i], 11, Ink(), true); h->Location = Point(17, 70);
                Label^ d = MakeLabel(descs[i], 8.5f, Muted(), false); d->Location = Point(17, 94); d->Size = Drawing::Size(cardW - 30, 35);
                c->Controls->Add(icon); c->Controls->Add(h); c->Controls->Add(d); pageHost->Controls->Add(c);
            }
            Label^ oop = MakeLabel("OOP IN ACTION  ·  Product abstraction  ·  CustomElixir inheritance  ·  Polymorphic tax calculation", 9, Forest(), true); oop->Location = Point(30, 475); pageHost->Controls->Add(oop);
            Button^ demo = MakeButton("Try the OOP demo  →", Forest(), Color::White, 190, 38); demo->Location = Point(28, 510); demo->Click += gcnew EventHandler(this, &MyForm::OopDemo_Click); pageHost->Controls->Add(demo);
        }

    public:
        MyForm(void) {
            cart = gcnew Dictionary<String^, int>();
            prices = gcnew Dictionary<String^, double>();
            descriptions = gcnew Dictionary<String^, String^>();
            icons = gcnew Dictionary<String^, String^>();
            oopProducts = gcnew List<Product^>();
            navigationButtons = gcnew List<Button^>();
            nextOrderNumber = 1001;
            prices->Add("Berry Bloom", 790); prices->Add("Matcha Cloud", 850); prices->Add("Golden Hour", 820); prices->Add("Blueberry Calm", 890); prices->Add("Sunny Side", 760); prices->Add("Rose Cloud", 880);
            descriptions->Add("Berry Bloom", "Strawberry · hibiscus · honey"); descriptions->Add("Matcha Cloud", "Matcha · oat milk · vanilla"); descriptions->Add("Golden Hour", "Mango · turmeric · ginger"); descriptions->Add("Blueberry Calm", "Blueberry · yogurt · chia"); descriptions->Add("Sunny Side", "Pineapple · lime · mint"); descriptions->Add("Rose Cloud", "Rose · vanilla · oat milk");
            icons->Add("Berry Bloom", "🍓"); icons->Add("Matcha Cloud", "🍵"); icons->Add("Golden Hour", "🥭"); icons->Add("Blueberry Calm", "🫐"); icons->Add("Sunny Side", "🍍"); icons->Add("Rose Cloud", "🌸");
            oopProducts->Add(gcnew CustomElixir("Berry Bloom", 790, "Hibiscus", 1));
            oopProducts->Add(gcnew CustomElixir("Matcha Cloud", 850, "Matcha", 2));
            InitializeComponent();
            BuildShell();
            SetPage("overview", "A little moment for yourself.", "YOUR ZENBAR SPACE");
        }

    protected:
        ~MyForm() { }

    private:
        void InitializeComponent(void) { }

        void BuildShell() {
            this->SuspendLayout();
            this->Text = L"ZenBar | Wellness, made personal";
            this->StartPosition = FormStartPosition::CenterScreen;
            this->ClientSize = Drawing::Size(1380, 850);
            this->MinimumSize = Drawing::Size(1050, 700);
            this->BackColor = Cream();
            this->Font = gcnew Drawing::Font(L"Segoe UI", 9.5f);
            this->AutoScaleMode = AutoScaleMode::Dpi;

            sidebar = MakePanel(Forest(), 238, 800); sidebar->Dock = DockStyle::Left;
            Label^ logo = MakeLabel("zenbar.", 27, Color::White, true); logo->Location = Point(24, 25); sidebar->Controls->Add(logo);
            Label^ tag = MakeLabel("YOUR DAILY WELLNESS BAR", 7.5f, Color::FromArgb(192, 211, 190), true); tag->Location = Point(27, 64); sidebar->Controls->Add(tag);
            Label^ workspace = MakeLabel("YOUR SPACE", 8, Color::FromArgb(162, 188, 164), true); workspace->Location = Point(27, 124); sidebar->Controls->Add(workspace);
            AddNavButton("▦   Overview", "overview", 151, true);
            AddNavButton("✿   Explore menu", "menu", 203, false);
            AddNavButton("▤   My orders", "orders", 255, false);
            AddNavButton("▣   Book a table", "bookings", 307, false);
            AddNavButton("♡   My wellness", "wellness", 359, false);
            AddNavButton("✧   Our story", "about", 411, false);

            Panel^ member = MakePanel(Color::FromArgb(62, 91, 68), 204, 76); member->Location = Point(17, 700); member->BorderStyle = BorderStyle::None;
            Panel^ avatar = MakePanel(Color::FromArgb(153, 183, 146), 40, 40); avatar->Location = Point(12, 17);
            Label^ z = MakeLabel("Z", 15, Forest(), true); z->AutoSize = false; z->Dock = DockStyle::Fill; z->TextAlign = ContentAlignment::MiddleCenter; avatar->Controls->Add(z);
            Label^ memberName = MakeLabel("Your Zen space", 9.5f, Color::White, true); memberName->Location = Point(62, 18);
            Label^ memberSub = MakeLabel("A little better, daily", 8, Color::FromArgb(200, 215, 197), false); memberSub->Location = Point(62, 42);
            member->Controls->Add(avatar); member->Controls->Add(memberName); member->Controls->Add(memberSub); sidebar->Controls->Add(member);
            this->Controls->Add(sidebar);

            mainArea = MakePanel(Cream(), 1100, 800); mainArea->Dock = DockStyle::Fill;
            topbar = MakePanel(White(), 1100, 76); topbar->Dock = DockStyle::Top;
            Label^ breadcrumb = MakeLabel("Workspace   /   A little space to feel good", 9, Muted(), false); breadcrumb->Location = Point(29, 29); topbar->Controls->Add(breadcrumb);
            cartCountLabel = MakeLabel("Bag  ·  0", 9, Forest(), true); cartCountLabel->Location = Point(0, 27); cartCountLabel->Anchor = AnchorStyles::Top | AnchorStyles::Right;
            Button^ bag = MakeButton("♡  View bag", Blush(), BlushDark(), 115, 35); bag->Location = Point(0, 20); bag->Anchor = AnchorStyles::Top | AnchorStyles::Right; bag->Click += gcnew EventHandler(this, &MyForm::GoOrders_Click);
            topbar->Controls->Add(cartCountLabel); topbar->Controls->Add(bag);
            topbar->Resize += gcnew EventHandler(this, &MyForm::Topbar_Resize);
            pageHost = MakePanel(Cream(), 1100, 720); pageHost->Dock = DockStyle::Fill; pageHost->AutoScroll = true; mainArea->Controls->Add(pageHost);
            mainArea->Controls->Add(topbar);
            Panel^ headingPanel = MakePanel(Cream(), 1100, 91); headingPanel->Dock = DockStyle::Top;
            pageEyebrow = MakeLabel("YOUR ZENBAR SPACE", 8, Sage(), true); pageEyebrow->Location = Point(29, 12);
            pageHeading = MakeLabel("A little moment for yourself.", 19, Ink(), true); pageHeading->Location = Point(27, 34);
            headingPanel->Controls->Add(pageEyebrow); headingPanel->Controls->Add(pageHeading); mainArea->Controls->Add(headingPanel); headingPanel->BringToFront();
            this->Controls->Add(mainArea); this->Controls->Add(sidebar); sidebar->BringToFront();
            this->ResumeLayout(true);
        }

        System::Void Topbar_Resize(Object^ sender, EventArgs^ e) {
            if (cartCountLabel != nullptr && topbar != nullptr) {
                cartCountLabel->Location = Point(Math::Max(200, topbar->ClientSize.Width - 250), 29);
                for each (Control^ c in topbar->Controls) {
                    Button^ b = dynamic_cast<Button^>(c);
                    if (b != nullptr) b->Location = Point(Math::Max(200, topbar->ClientSize.Width - 145), 20);
                }
            }
        }

        System::Void AddToBag_Click(Object^ sender, EventArgs^ e) {
            Button^ b = safe_cast<Button^>(sender); AddProduct(safe_cast<String^>(b->Tag));
        }
        System::Void GoMenu_Click(Object^ sender, EventArgs^ e) { SetPage("menu", "Find your feel-good blend.", "THE MENU"); }
        System::Void GoOrders_Click(Object^ sender, EventArgs^ e) { SetPage("orders", "Your little list of goodness.", "YOUR ORDER"); }
        System::Void GoBookings_Click(Object^ sender, EventArgs^ e) { SetPage("bookings", "Make a little room for you.", "VISIT ZENBAR"); }

        System::Void RemoveOrder_Click(Object^ sender, EventArgs^ e) {
            Button^ b = safe_cast<Button^>(sender); DataGridView^ grid = safe_cast<DataGridView^>(b->Tag);
            if (grid->SelectedRows->Count == 0) { MessageBox::Show("Select a blend in your bag first.", "Nothing selected", MessageBoxButtons::OK, MessageBoxIcon::Information); return; }
            String^ name = Convert::ToString(grid->SelectedRows[0]->Cells[0]->Value);
            if (cart->ContainsKey(name)) cart->Remove(name);
            SetPage("orders", "Your little list of goodness.", "YOUR ORDER");
        }
        System::Void ClearBag_Click(Object^ sender, EventArgs^ e) {
            cart->Clear(); SetPage("orders", "Your little list of goodness.", "YOUR ORDER");
        }
        System::Void PlaceOrder_Click(Object^ sender, EventArgs^ e) {
            if (cart->Count == 0) { MessageBox::Show("Your bag is empty. Explore the menu and add a blend first.", "A little reminder", MessageBoxButtons::OK, MessageBoxIcon::Information); return; }
            double total = CartTotal();
            MessageBox::Show("Your demo order has been placed!\n\nOrder number: ZB-" + nextOrderNumber.ToString() + "\nTotal: LKR " + total.ToString("0.00") + "\n\nThank you for choosing ZenBar. ♡", "Order placed", MessageBoxButtons::OK, MessageBoxIcon::Information);
            nextOrderNumber++; cart->Clear(); SetPage("orders", "Your little list of goodness.", "YOUR ORDER");
        }
        System::Void SubmitBooking_Click(Object^ sender, EventArgs^ e) {
            Button^ b = safe_cast<Button^>(sender); Panel^ card = safe_cast<Panel^>(b->Tag);
            DateTimePicker^ date = nullptr; ComboBox^ time = nullptr; NumericUpDown^ guests = nullptr;
            for each (Control^ c in card->Controls) {
                if (c->Name == "bookingDate") date = dynamic_cast<DateTimePicker^>(c);
                else if (c->Name == "bookingTime") time = dynamic_cast<ComboBox^>(c);
                else if (c->Name == "bookingGuests") guests = dynamic_cast<NumericUpDown^>(c);
            }
            if (date == nullptr || time == nullptr || guests == nullptr) return;
            MessageBox::Show("Your booking request is ready!\n\nDate: " + date->Value.ToString("dddd, dd MMMM yyyy") + "\nTime: " + time->Text + "\nGuests: " + guests->Value.ToString() + "\n\nThis is a demo booking; it has not been sent to a real reservation system.", "Booking request", MessageBoxButtons::OK, MessageBoxIcon::Information);
        }
        System::Void MoodPick_Click(Object^ sender, EventArgs^ e) {
            Button^ b = safe_cast<Button^>(sender); int i = safe_cast<int>(b->Tag);
            array<String^>^ names = gcnew array<String^>{"Golden Hour", "Matcha Cloud", "Sunny Side", "Berry Bloom"};
            AddProduct(names[i]);
        }
        System::Void OopDemo_Click(Object^ sender, EventArgs^ e) {
            String^ report = "ZENBAR OOP DEMONSTRATION\n\n";
            for each (Product^ p in oopProducts) {
                report += "Product: " + p->Name + "\nPrice: LKR " + p->Price.ToString("0.00") + "\nTax (polymorphic): LKR " + p->CalculateTax().ToString("0.00") + "\n\n";
            }
            report += "Product is an abstract base class. CustomElixir inherits from Product and overrides CalculateTax().\nThis demonstrates abstraction, inheritance, encapsulation and runtime polymorphism.";
            MessageBox::Show(report, "ZenBar · OOP in action", MessageBoxButtons::OK, MessageBoxIcon::Information);
        }
    };
}
